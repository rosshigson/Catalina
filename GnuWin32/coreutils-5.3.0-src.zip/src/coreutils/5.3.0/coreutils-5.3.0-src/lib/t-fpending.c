/* Ensure that __fpending works.  */

#include <config.h>
#include <stdio.h>
#include <stdlib.h>

#include "__fpending.h"

int
main ()
{
  int n;
  
  if ((n=__fpending (stdout)) != 0) {
  	printf ("1: %d\n", n);
    abort ();
  }

  fputs ("foo", stdout);
  if ((n=__fpending (stdout)) != 3) {
  	printf ("2: %d\n", n);
    abort ();
  }

  fflush (stdout);
  if ((n=__fpending (stdout)) != 0) {
  	printf ("3: %d\n", n);
    abort ();
  }

  exit (0);
}
