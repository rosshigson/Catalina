#include "checksum.h"
int algorithm = ALG_SHA1;
