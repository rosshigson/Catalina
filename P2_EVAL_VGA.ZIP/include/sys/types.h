typedef long            off_t;

