# For complete documentation of this file, please see Geany's main documentation
[styling]
# Edit these in the colorscheme .conf file instead
default=default
comment=comment
commentline=comment_line
commentdoc=comment_doc
preprocessorcomment=comment
preprocessorcommentdoc=comment_doc
number=number_1
word=keyword_1
word2=keyword_2
string=string_1
stringraw=string_2
character=character
userliteral=other
uuid=other
preprocessor=preprocessor
operator=operator
identifier=identifier_1
stringeol=string_eol
verbatim=string_2
regex=regex
commentlinedoc=comment_line_doc
commentdockeyword=comment_doc_keyword
commentdockeyworderror=comment_doc_keyword_error
globalclass=class
# """verbatim"""
tripleverbatim=string_2
hashquotedstring=string_2
taskmarker=comment
escapesequence=string_1

[keywords]
# all items must be in one line
primary=asm auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while _Alignas _Alignof _Atomic _Bool _Complex _Generic _Imaginary _Noreturn _Static_assert _Thread_local FALSE NULL TRUE
secondary=
# these are the Doxygen keywords
docComment=a addindex addtogroup anchor arg attention author authors b brief bug c callergraph callgraph category cite class code cond copybrief copydetails copydoc copyright date def defgroup deprecated details dir dontinclude dot dotfile e else elseif em endcode endcond enddot endhtmlonly endif endinternal endlatexonly endlink endmanonly endmsc endrtfonly endverbatim endxmlonly enum example exception extends file fn headerfile hideinitializer htmlinclude htmlonly if ifnot image implements include includelineno ingroup interface internal invariant latexonly li line link mainpage manonly memberof msc mscfile n name namespace nosubgrouping note overload p package page par paragraph param post pre private privatesection property protected protectedsection protocol public publicsection ref related relatedalso relates relatesalso remark remarks result return returns retval rtfonly sa section see short showinitializer since skip skipline snippet struct subpage subsection subsubsection tableofcontents test throw throws todo tparam typedef union until var verbatim verbinclude version warning weakgroup xmlonly xrefitem

[lexer_properties]
styling.within.preprocessor=1
lexer.cpp.track.preprocessor=0

[settings]
# default extension used when saving files
extension=c

# MIME type
mime_type=text/x-csrc

# the following characters are these which a "word" can contains, see documentation
#wordchars=_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789

# single comments, like # in this file
comment_single=//
# multiline comments
comment_open=/*
comment_close=*/

# set to false if a comment character/string should start at column 0 of a line, true uses any
# indentation of the line, e.g. setting to true causes the following on pressing CTRL+d
	#command_example();
# setting to false would generate this
#	command_example();
# This setting works only for single line comments
comment_use_indent=true

# context action command (please see Geany's main documentation for details)
context_action_cmd=

[indentation]
#width=4
# 0 is spaces, 1 is tabs, 2 is tab & spaces
#type=1

[build-menu]
# %f will be replaced by the complete filename
# %e will be replaced by the filename without extension
# (use only one of it at one time)
FT_00_LB=_Compile
FT_00_CM=catalina %o -c "%d/%f"
FT_00_WD=%p
FT_01_LB=_Build
FT_01_CM=catalina %o "%d/%f" -o "%e"
FT_01_WD=%p
FT_02_LB=Compile _All
FT_02_CM=catalina -c %o *.c
FT_02_WD=%p
FT_03_LB=_Link 
FT_03_CM=catalina %o *.o -o "%e"
FT_03_WD=%p
FT_04_LB=Clea_n
FT_04_CM=rm -f "%e" *.binary *.eeprom *.bin *.debug *.dbg *.lst *.o *.s
FT_04_WD=%p
FT_05_LB=
FT_05_CM=
FT_05_WD=
NF_00_LB=_Make
NF_00_CM=make "%n" CATALINA_OPTIONS="%o" 
NF_00_WD=%p
NF_01_LB=Make (Custom _Target...)
NF_01_CM=make CATALINA_OPTIONS="%o" 
NF_01_WD=%p
NF_02_LB=
NF_02_CM=
NF_02_WD=
NF_03_LB=
NF_03_CM=
NF_03_WD=
EX_00_LB=Download and _Execute
EX_00_CM=payload %x "%e" -b%b 
EX_00_WD=%p
EX_01_LB=Download and _Interact
EX_01_CM=payload %x "%e" -i -b%b 
EX_01_WD=%p
EX_02_LB=_Debug with BlackBox
EX_02_CM=blackbox "%e"
EX_02_WD=%p
EX_03_LB=Build _Utilities
EX_03_CM=build_utilities 
EX_03_WD=
EX_04_LB=Build C_atalyst
EX_04_CM=build_catalyst 
EX_04_WD=
EX_05_LB=Catalina Command _Line
EX_05_CM=bash --init-file /opt/catalina/use_catalina
EX_05_WD=%p
