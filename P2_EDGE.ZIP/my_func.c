
/* simple function to return the square of argument */

int func (int a) {
	return a * a;
}

