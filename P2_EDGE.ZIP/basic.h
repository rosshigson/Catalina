#ifndef basic_h
#define basic_h
/*
  Minibasic header file
  By Malcolm Mclean
*/

int basic(const char *script, FILE *in, FILE *out, FILE *err);

#endif

