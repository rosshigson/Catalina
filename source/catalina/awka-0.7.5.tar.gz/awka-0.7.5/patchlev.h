#define AWKAVERSION "0.7.5"
#define DATE_STRING "12 July 2001"
