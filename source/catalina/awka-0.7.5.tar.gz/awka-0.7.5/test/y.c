#include <stdio.h>

int main()
{
  int i=0;

  printf("%#.0o\n",i);
}
