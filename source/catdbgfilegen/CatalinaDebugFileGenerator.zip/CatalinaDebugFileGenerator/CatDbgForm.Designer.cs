﻿namespace CatalinaDebugFileGenerator
{
    partial class CatDbgForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.tbxTop = new System.Windows.Forms.TextBox();
            this.tbxBottom = new System.Windows.Forms.TextBox();
            this.menuMain = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openListingFilelstToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearTopListBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearBottomListBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showTypedefsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showStandardTypedefsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openListingFile = new System.Windows.Forms.OpenFileDialog();
            this.openDebugFile = new System.Windows.Forms.OpenFileDialog();
            this.tbxDebugDirectory1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbxDebugDirectory3 = new System.Windows.Forms.TextBox();
            this.tbxDebugDirectory2 = new System.Windows.Forms.TextBox();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.menuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer.Location = new System.Drawing.Point(1, 38);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.tbxTop);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.tbxBottom);
            this.splitContainer.Size = new System.Drawing.Size(888, 501);
            this.splitContainer.SplitterDistance = 60;
            this.splitContainer.TabIndex = 0;
            // 
            // tbxTop
            // 
            this.tbxTop.BackColor = System.Drawing.Color.White;
            this.tbxTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbxTop.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxTop.Location = new System.Drawing.Point(0, 0);
            this.tbxTop.Multiline = true;
            this.tbxTop.Name = "tbxTop";
            this.tbxTop.ReadOnly = true;
            this.tbxTop.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbxTop.Size = new System.Drawing.Size(888, 60);
            this.tbxTop.TabIndex = 0;
            this.tbxTop.WordWrap = false;
            // 
            // tbxBottom
            // 
            this.tbxBottom.BackColor = System.Drawing.Color.White;
            this.tbxBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbxBottom.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxBottom.Location = new System.Drawing.Point(0, 0);
            this.tbxBottom.Multiline = true;
            this.tbxBottom.Name = "tbxBottom";
            this.tbxBottom.ReadOnly = true;
            this.tbxBottom.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbxBottom.Size = new System.Drawing.Size(888, 437);
            this.tbxBottom.TabIndex = 0;
            this.tbxBottom.WordWrap = false;
            // 
            // menuMain
            // 
            this.menuMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.menuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.operationsToolStripMenuItem});
            this.menuMain.Location = new System.Drawing.Point(0, 0);
            this.menuMain.Name = "menuMain";
            this.menuMain.Size = new System.Drawing.Size(892, 24);
            this.menuMain.TabIndex = 1;
            this.menuMain.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openListingFilelstToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openListingFilelstToolStripMenuItem
            // 
            this.openListingFilelstToolStripMenuItem.Name = "openListingFilelstToolStripMenuItem";
            this.openListingFilelstToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.openListingFilelstToolStripMenuItem.Text = "Open Listing File (*.lst)";
            this.openListingFilelstToolStripMenuItem.Click += new System.EventHandler(this.openListingFilelstToolStripMenuItem_Click);
            // 
            // operationsToolStripMenuItem
            // 
            this.operationsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showToolStripMenuItem,
            this.clearTopListBoxToolStripMenuItem,
            this.clearBottomListBoxToolStripMenuItem,
            this.showTypedefsToolStripMenuItem,
            this.showStandardTypedefsToolStripMenuItem});
            this.operationsToolStripMenuItem.Name = "operationsToolStripMenuItem";
            this.operationsToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.operationsToolStripMenuItem.Text = "Operations";
            // 
            // showToolStripMenuItem
            // 
            this.showToolStripMenuItem.Name = "showToolStripMenuItem";
            this.showToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.showToolStripMenuItem.Text = "Generate dbg File";
            this.showToolStripMenuItem.Click += new System.EventHandler(this.showToolStripMenuItem_Click);
            // 
            // clearTopListBoxToolStripMenuItem
            // 
            this.clearTopListBoxToolStripMenuItem.Name = "clearTopListBoxToolStripMenuItem";
            this.clearTopListBoxToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.clearTopListBoxToolStripMenuItem.Text = "Clear Top List Box";
            this.clearTopListBoxToolStripMenuItem.Click += new System.EventHandler(this.clearTopListBoxToolStripMenuItem_Click);
            // 
            // clearBottomListBoxToolStripMenuItem
            // 
            this.clearBottomListBoxToolStripMenuItem.Name = "clearBottomListBoxToolStripMenuItem";
            this.clearBottomListBoxToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.clearBottomListBoxToolStripMenuItem.Text = "Clear Bottom List Box";
            this.clearBottomListBoxToolStripMenuItem.Click += new System.EventHandler(this.clearBottomListBoxToolStripMenuItem_Click);
            // 
            // showTypedefsToolStripMenuItem
            // 
            this.showTypedefsToolStripMenuItem.Name = "showTypedefsToolStripMenuItem";
            this.showTypedefsToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.showTypedefsToolStripMenuItem.Text = "Show Added Typedefs";
            this.showTypedefsToolStripMenuItem.Click += new System.EventHandler(this.showTypedefsToolStripMenuItem_Click);
            // 
            // showStandardTypedefsToolStripMenuItem
            // 
            this.showStandardTypedefsToolStripMenuItem.Name = "showStandardTypedefsToolStripMenuItem";
            this.showStandardTypedefsToolStripMenuItem.Size = new System.Drawing.Size(220, 22);
            this.showStandardTypedefsToolStripMenuItem.Text = "Show Standard Typedefs";
            this.showStandardTypedefsToolStripMenuItem.Click += new System.EventHandler(this.showStandardTypedefsToolStripMenuItem_Click);
            // 
            // openListingFile
            // 
            this.openListingFile.FileName = "*.lst";
            this.openListingFile.Filter = "Listing files|*.lst|All files|*.*";
            // 
            // openDebugFile
            // 
            this.openDebugFile.FileName = "*.debug";
            this.openDebugFile.Filter = "Debug files|*.debug|All files|*.*";
            // 
            // tbxDebugDirectory1
            // 
            this.tbxDebugDirectory1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbxDebugDirectory1.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxDebugDirectory1.Location = new System.Drawing.Point(118, 547);
            this.tbxDebugDirectory1.Name = "tbxDebugDirectory1";
            this.tbxDebugDirectory1.Size = new System.Drawing.Size(249, 22);
            this.tbxDebugDirectory1.TabIndex = 2;
            this.tbxDebugDirectory1.WordWrap = false;
            this.tbxDebugDirectory1.TextChanged += new System.EventHandler(this.tbxDebugDirectory_TextChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 552);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Debug file paths:";
            // 
            // tbxDebugDirectory3
            // 
            this.tbxDebugDirectory3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbxDebugDirectory3.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxDebugDirectory3.Location = new System.Drawing.Point(620, 547);
            this.tbxDebugDirectory3.Name = "tbxDebugDirectory3";
            this.tbxDebugDirectory3.Size = new System.Drawing.Size(249, 22);
            this.tbxDebugDirectory3.TabIndex = 4;
            this.tbxDebugDirectory3.WordWrap = false;
            this.tbxDebugDirectory3.TextChanged += new System.EventHandler(this.tbxDebugDirectory3_TextChanged);
            // 
            // tbxDebugDirectory2
            // 
            this.tbxDebugDirectory2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbxDebugDirectory2.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxDebugDirectory2.Location = new System.Drawing.Point(369, 547);
            this.tbxDebugDirectory2.Name = "tbxDebugDirectory2";
            this.tbxDebugDirectory2.Size = new System.Drawing.Size(249, 22);
            this.tbxDebugDirectory2.TabIndex = 5;
            this.tbxDebugDirectory2.WordWrap = false;
            this.tbxDebugDirectory2.TextChanged += new System.EventHandler(this.tbxDebugDirectory2_TextChanged);
            // 
            // CatDbgForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 573);
            this.Controls.Add(this.tbxDebugDirectory2);
            this.Controls.Add(this.tbxDebugDirectory3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbxDebugDirectory1);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.menuMain);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuMain;
            this.Name = "CatDbgForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Catalina Debug File Generator";
            this.Shown += new System.EventHandler(this.CatDbgForm_Shown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CatDbgForm_FormClosing);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            this.splitContainer.ResumeLayout(false);
            this.menuMain.ResumeLayout(false);
            this.menuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.MenuStrip menuMain;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openListingFilelstToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openListingFile;
        private System.Windows.Forms.TextBox tbxTop;
        private System.Windows.Forms.ToolStripMenuItem operationsToolStripMenuItem;
        private System.Windows.Forms.TextBox tbxBottom;
        private System.Windows.Forms.OpenFileDialog openDebugFile;
        private System.Windows.Forms.TextBox tbxDebugDirectory1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearTopListBoxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearBottomListBoxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showTypedefsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showStandardTypedefsToolStripMenuItem;
        private System.Windows.Forms.TextBox tbxDebugDirectory3;
        private System.Windows.Forms.TextBox tbxDebugDirectory2;
    }
}

