﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using CatDbgUtilities;


namespace CatalinaDebugFileGenerator
{
    public partial class CatDbgForm : Form
    {

        public CatDbgForm()
        {
            InitializeComponent();
        }

        DbgDLL DbgLib = new DbgDLL();

        private void CatDbgForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Later, we'll find a need to do other things when the user closes the program.
            SaveSizeAndLocationOfMainForm();
        }

        private void SaveSizeAndLocationOfMainForm()
        {
            Properties.Settings.Default.mainFormSize     = this.Size;
            Properties.Settings.Default.mainFormLocation = this.Location;
            Properties.Settings.Default.Save();
        }

        private void openListingFilelstToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openListingFile.ShowDialog() == DialogResult.OK)
            {
                DbgLib.FillListFile(openListingFile.FileName);

                tbxTop.Clear();
                tbxTop.AppendText("Loaded " + openListingFile.FileName + "\r\n" );
            }
        }

        private void getSourceFileNamesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Here we provide for manual invocation of get source filenames.  This is just for debug
            // as asking to produce a .dbg file automatically calls GetSourceFileNamesFromListFile()
            //DbgLib.GetSourceFileNamesFromListFile();  
        }

        private void CatDbgForm_Shown(object sender, EventArgs e)
        {
            this.Size     = Properties.Settings.Default.mainFormSize;
            this.Location = Properties.Settings.Default.mainFormLocation;
            tbxDebugDirectory1.Text = Properties.Settings.Default.debugFilesPath1;
            tbxDebugDirectory2.Text = Properties.Settings.Default.debugFilesPath2;
            tbxDebugDirectory3.Text = Properties.Settings.Default.debugFilesPath3;
        }

        private void showToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbxBottom.Clear();
            List<string> debugFilePaths = new List<string>();

            if (tbxDebugDirectory1.Text != "") debugFilePaths.Add(tbxDebugDirectory1.Text);
            if (tbxDebugDirectory2.Text != "") debugFilePaths.Add(tbxDebugDirectory2.Text);
            if (tbxDebugDirectory3.Text != "") debugFilePaths.Add(tbxDebugDirectory3.Text);

            // Go build the .dbg file
            DbgLib.GenerateDbgFile(debugFilePaths);

            // Extract the .dbg file as a string and display it.
            tbxBottom.AppendText(DbgLib.GetOutputString());
        }

        private void tbxDebugDirectory_TextChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.debugFilesPath1 = tbxDebugDirectory1.Text;
            Properties.Settings.Default.Save();
        }

        private void clearTopListBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbxTop.Clear();
        }

        private void clearBottomListBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tbxBottom.Clear();
        }

        private void showTypedefsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showTypedefsToolStripMenuItem.Checked = DbgLib.ToggleShowNewTypeDefs();
        }

        private void showStandardTypedefsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showStandardTypedefsToolStripMenuItem.Checked = DbgLib.ToggleShowStdTypeDefs();
        }

        private void tbxDebugDirectory2_TextChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.debugFilesPath2 = tbxDebugDirectory2.Text;
            Properties.Settings.Default.Save();
        }

        private void tbxDebugDirectory3_TextChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.debugFilesPath3 = tbxDebugDirectory3.Text;
            Properties.Settings.Default.Save();
        }
    }
}
