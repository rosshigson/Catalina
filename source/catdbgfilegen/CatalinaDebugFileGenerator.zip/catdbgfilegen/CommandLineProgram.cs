﻿using System;
using System.Collections.Generic;
using System.Text;
using CatDbgUtilities;

namespace catdbgfilegen
{
    class CommandLineProgram
    {

        static int Main(string[] args)
        {
            int argc = args.Length;

            if (argc < 2)
            {
                Console.WriteLine("");
                Console.WriteLine("Usage: catdbgfilegen \"path to .lst\"  \"-d .debug files dir\" [-s] [-n] [-linux]");
                Console.WriteLine("       -s  option: include standard  TYPEDEF lines in output");
                Console.WriteLine("       -n  option: include generated TYPEDEF lines in output");
                Console.WriteLine("       -d  option: path to .debug files -- multiple entries accepted");
                Console.WriteLine("   -linux  option: use Linux file conventions (needed if no / present in args");
                Console.WriteLine("  returns  0 if processing completed normally");
                Console.WriteLine("  returns -1 if .lst file could not be opened or error in cmd line arguments");
                Console.WriteLine("  returns -2 for any other error -- these are detailed in .dbg file");
                Console.WriteLine("");

                return -1;
            }

            // Launch (and name for local use) the dll that does all the heavy lifting.

            DbgDLL DbgLib = new DbgDLL();

            // There is a GUI version that is used for testing that allows typedefs to be
            // toggled on or off by a menu click.  Here we make sure that, if the user inadvertently
            // puts multiple -s or -n options in the command line, he will still get what he expects.
            // That is the purpose of the two bools that follow.
            
            bool showStandardTypedefs   = false;
            bool showNewTypedefs        = false;

            // We will accumulate the various paths to debug files in this list of strings.

            List<string> debugFilePaths = new List<string>();
            
            for( int i = 1; i<argc; i++ )
            {
                if (args[i].StartsWith("-s"))
                {
                    showStandardTypedefs = true;
                    continue;
                }

                if (args[i].StartsWith("-n"))
                {
                    showNewTypedefs = true;
                    continue;
                }

                if (args[i].StartsWith("-linux") || args[i].Contains("/"))
                {
                    DbgLib.SetLinux(true);
                    continue;
                }

                if (args[i].StartsWith("-d"))
                {
                    // Next argument is a path to a .debug directory.  Make
                    // sure that there IS a next argument.
                    if ( ++i < argc )
                    {
                        debugFilePaths.Add(args[i]);
                        continue;
                    }
                    else{
                        return -1;
                    }
                }

                // If this point is reached, there was an unrecognized command line option.
                return -1;
            }

            if (showStandardTypedefs) DbgLib.ToggleShowStdTypeDefs();
            if (showNewTypedefs     ) DbgLib.ToggleShowNewTypeDefs();

            // The FillListFile() routine builds a symbol table (hashed) and a list of source files (with full path)
            // from information extracted from the .lst file
            
            int result = DbgLib.FillListFile(args[0]);

            if (result != 0)
            {
                // Failed to open and read .lst file.  We have to report this this way because
                // a .dbg file is not open in this case.
                return -1;
            }

            // Note: Now that we can open the .lst file, we are also able to write a .dbg file,
            // so any further errors will be recorded there in detail.
            
            DbgLib.GenerateDbgFile(debugFilePaths);     // Go generate a .dbg file

            string results = DbgLib.GetOutputString();  // Get a copy of the .dbg file

            // Any error, including not being able to open a .debug directory, or find
            // a required .debug file is reported in the .dbg file in a line that starts with =====
            
            if (results.Contains("====="))
                return -2;
            else
                return 0;
        }
    }
}
