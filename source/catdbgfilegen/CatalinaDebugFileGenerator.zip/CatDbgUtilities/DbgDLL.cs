﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.IO;

namespace CatDbgUtilities
{
    public class DbgDLL
    {
        
        #region Globals

        string RelocConstantString = "0";

        string TheTotalText;

        string NewLine = "\r\n";

        // We use this flag to set "FirstLineLoc" when the first stabn 0x44 is encountered
        bool WaitingForFirst0x44 = true;

        // These strings are used to record the range of locations (PC value at breakpoint)
        // that are in this source file.
        string FirstLineLoc = "";
        string LastLineLoc = "";

        string CurrentProc = "";
        int LexLevel = 0;

        // Each string in this list holds the var name, type, and loc for variables
        // declared at lex levels over 1.
        List<string> VisibleVars = new List<string>();

        string ProjectDirectory = "";
        string ListFilePath     = "";

        bool Linux = false;

        bool InCatalinaSpinSegment = false;

        // Following is the string that we search for at the end of a ListFile string
        // when we're trying to find what source files were included in the build.
        string FileNameTerminationText = "_00_text0";

        // This list gets populated with the source pathnames found in the ListFile
        List<string> SourceFileList = new List<string>();

        // This list holds all the lines read from the listing file.
        List<string> ListFile = new List<string>();

        // This dictionary holds the symbols extracted during the building of ListFile.
        Dictionary<string,string> SymbolTable = new Dictionary<string,string>();

        // This list holds the lines from the current .debug file that is being processed.
        List<string> DebugFile = new List<string>();

        List<string> ReorderedDebugFile = new List<string>();

        // and this list holds the output lines.  We use this  list for post-processing the
        // output grouping
        List<string> DebugOutput = new List<string>();

        // This list (rebuilt as each .debug file is processed) holds all the typedefs found.
        List<string> TypeDefs = new List<string>();

        // This string accumulates all of the output lines.  They are then available at the
        // end of the .dbg generating phase to dump to txbBottom (very fast operation), to be
        // searched for ==== (some error occurred), and written to a file.
        string OutputString = "";

        int  MaxStandardTypeValue = 15;  // Controls which typedefs are considered standard and which are new

        bool ShowNewTypeDefs = false;    // If true, new typedefs are included in the output.
        bool ShowStdTypeDefs = false;    // If true, standard typedefs are included inthe output.

        #endregion

        #region Public methods

        private string ExtractHubAddress(string aLine)
        {
            // Format of lines that contain a hub address...
            //    0244(007f):             ' C_when_to_work ' <symbol:when_to_work>

            string ans = "0x";
            int i;

            // We are going to accumulate all charactes from aLine up to the first (
            // Here we protect ourselves from a mal-formed aLine that does not contain a (
            // We also assume that no valid address string can contain more than 8 hex characters.

            int searchCount = aLine.Length;
            if (searchCount > 8) searchCount = 8;

            for (i = 0; i < searchCount; i++)
            {
                if (aLine[i] != '(')
                {
                    ans += aLine[i];
                }
                else
                {
                    break;
                }
            }
            return ans;
        }

        private void AddToSymbolTable(string aLine)
        {
            if (aLine.StartsWith("'") && aLine.Contains("Catalina.spin" ) )
            {
                InCatalinaSpinSegment = true;
                return;
            }

            if (InCatalinaSpinSegment && aLine.EndsWith( "object pointers" ) )
            {
                char[] splitChar = {':'};
                string[] parts = aLine.Split( splitChar );

                RelocConstantString = parts[0];
                InCatalinaSpinSegment = false;
 
                return;
            }

            if (aLine.EndsWith(FileNameTerminationText))
            {
                string sourceFileName = ExtractSourceFileName(aLine);
                SourceFileList.Add(sourceFileName);
                AddToOutput(sourceFileName);
                return;
            }

            string key;

            // Handle lines like...
            //    01d8(0064):             ' L__BobsAddAtoB_2ec_00_11

            int Spos = aLine.LastIndexOf("L__");
            if (Spos >= 0)
            {
                key = aLine.Remove(0, Spos);
                SymbolTable[key] = ExtractHubAddress(aLine);
                return;
            }

            // Handle lines like...
            //    0244(007f):             ' C_when_to_work ' <symbol:when_to_work>
  
            if (aLine.EndsWith(">"))
            {
                Spos = aLine.LastIndexOf('<');
                if (Spos >= 0)
                {
                    string symStr = aLine.Remove(0, Spos);
                    char[] splitChars = { '<',':','>' };
                    string[] parts = symStr.Split( splitChars, StringSplitOptions.RemoveEmptyEntries );
                    if (parts.Length != 2) return;   // Mal-formed symbol designator in list file
                    SymbolTable[parts[1]] = ExtractHubAddress(aLine);
                }

                // Added to deal with statics Feb 7 2010

                char[] quoteChar = { '\'' };
                string[] moreParts = aLine.Split(quoteChar, StringSplitOptions.RemoveEmptyEntries);
                if (moreParts.Length != 3) return;  // Mal-formed symbol designator in list file
                string lookUpKey = moreParts[1].Trim();
                SymbolTable[lookUpKey] = ExtractHubAddress(aLine);
            }
        }

        public int FillListFile(string listFilePath)
        {
            // We keep the listing file in a list of strings.  We will be searching the listing
            // file frequently for items and it's nice to able to use the foreach( ){ } structure.
            SymbolTable.Clear();
            SourceFileList.Clear();
            InCatalinaSpinSegment = false;
            ListFile.Clear();

            TheTotalText = "We no longer load the listing file into this window because of the time it took." + NewLine;

            ListFilePath = listFilePath;

            try
            {
                using (StreamReader sr = new StreamReader(listFilePath))
                {
                    while (!sr.EndOfStream)
                    {
                        string aLine = sr.ReadLine();

                        ListFile.Add(aLine);

                        // Check for aLine containing a symbol that needs to be in SymbolTable
                        // This routine also builds the SourceFileList and looks for the relocation
                        // value to translate listing file addresses to final hub addresses.
                        AddToSymbolTable(aLine);
                    }
                }
            }
            catch  // Any problems trying to read the .lst file.
            {
                return -1;
            }
            return 0;
        }

        public void SetLinux(bool linuxConventionForFilenames)
        {
            Linux = linuxConventionForFilenames;
        }

        public int GenerateDbgFile(List<string> debugPaths)
        {
            // This is the routine that is called to process ListFile (loaded) and
            // symbol tables extracted during the reading of ListFile into
            // a .dbg file.

            OutputString = "";
            DebugOutput.Clear();

            // Check that all supplied .debug file directories actually exist.
            // Supply proper directory trailer if not already present.

            string debugPath = "";

            for (int i = 0; i < debugPaths.Count; i++)
            {
                debugPath = debugPaths[i];
                DirectoryInfo DirInfo = null;

                // When a user is asked for a path, it is ambiguous as to whether the path should
                // have a \ (or /) at the end or not.  Here we add the \ (or /) if the user hadn't.
                if (!Linux && !debugPath.EndsWith("\\"))
                {
                    debugPath += "\\";  // Windows convention
                }

                if (Linux && !debugPath.EndsWith("/"))
                {
                    debugPath += "/";  // Linux convention
                }

                // Make sure that user has specified a valid debug directory.
                try
                {
                    DirInfo = new DirectoryInfo(debugPath);
                    if (!DirInfo.Exists)
                    {
                        AddToOutput("===== debug files directory provided does not exist.");
                        PostProcessDebugOutput();
                        WriteOutputToDbgFile();
                        return -1;
                    }
                }
                catch (Exception err)
                {
                    AddToOutput("===== Problem with debug files directory path: " + err.Message);
                    PostProcessDebugOutput();
                    WriteOutputToDbgFile();
                    return -1;
                }

                debugPaths[i] = debugPath;
            }

            OutputString = "";
            DebugOutput.Clear();

            AddToOutput("RELOC " + RelocConstantString + "   (subtract this value from listing address to get hub address)" );
            AddToOutput("");
            PostProcessDebugOutput();
            WriteOutputToDbgFile();

            // This routine iterates through all the source files found and finds and processes
            // the associated .debug files.
            ProcessSourceFileList(debugPaths);

            WriteOutputToDbgFile();
            return 0;
        }
        
        public string GetOutputString()
        {
            return OutputString;
        }
        
        public bool ToggleShowNewTypeDefs()
        {
            ShowNewTypeDefs = !ShowNewTypeDefs;
            return ShowNewTypeDefs;
        }

        public bool ToggleShowStdTypeDefs()
        {
            ShowStdTypeDefs = !ShowStdTypeDefs;
            return ShowStdTypeDefs;
        }

        // This routine is only used by the Windows version to populate the top window
        // with the contents of the *.lst file.
        public string GetTheTotalText()
        {
            return TheTotalText;
        }

        #endregion

        #region Private methods

        #region stabx handlers

        private void Process_stabs_0x64(string[] stablineParts) // SOURCE filename
        {
            // Here is a typical example of what we're trying to process...

            // The following example is from a case where Code::Blocks specified a relative path to the source code
            //   .stabs "C:\Bobs C code\CatalinaOne/",0x64,0,3,L___2e_2e_5cBobs_20Test_20Main_2ec_00_text0
            //   .stabs "..\Bobs Test Main.c",0x64,0,3,L___2e_2e_5cBobs_20Test_20Main_2ec_00_text0

            // In the following example, Code::Blocks is using an absolute path...
            //    .stabs "C:\Bobs C code\CatalinaOne/",0x64,0,3,L__I_3a_5cRemote_20Drive_20C_20Programs_5cBobsSubBfromA_2ec_00_text0
            //    .stabs "I:\Remote Drive C Programs\BobsSubBfromA.c",0x64,0,3,L__I_3a_5cRemote_20Drive_20C_20Programs_5cBobsSubBfromA_2ec_00_text0

            //string[] stablineParts;
            string sourcePath = "";

            //stablineParts = ParseStabs(s);

            if (stablineParts[0].EndsWith("/"))
            {
                // The / indicates that this 0x64 line contains the project directory path
                char[] trimChar = { '/' };
                ProjectDirectory = stablineParts[0].TrimEnd(trimChar);

                // Here we try to auto-detect that Linux paths are in use.
                Linux = ProjectDirectory.Contains("/");

                // There is no need to show the project directory.  The following line was for debugging.
                // AddToOutput("PROJDIR " + "\"" + ProjectDirectory + "\"");
            }
            else
            {
                // We're now on the second 0x64 line and need to determine if a relative or absolute
                // path is in use.  For Linux, absolute paths start with / while for Windows, there
                // will be a : after the drive designator.

                // One more chance to auto-detect Linux path convention is in use.
                Linux = Linux || stablineParts[0].Contains("/");

                if (Linux)
                {
                    if (stablineParts[0].StartsWith("/"))
                        // Absolute
                        sourcePath = stablineParts[0];
                    else
                        // Relative
                        sourcePath = ProjectDirectory + "/" + stablineParts[0];
                }
                else
                {
                    if (stablineParts[0].Contains(":"))
                        // Absolute
                        sourcePath = stablineParts[0];
                    else
                        // Relative
                        sourcePath = ProjectDirectory + "\\" + stablineParts[0];
                }
                AddToOutput("SOURCE  " + "\"" + sourcePath + "\"");
            }
        }

        private void Process_stabs_0x84(string[] stablineParts)  // SOURCE
        {
            string sourcePath = "";
            sourcePath = ProjectDirectory + "\\" + stablineParts[0];
            AddToOutput("INCSRC  " + "\"" + sourcePath + "\"");
            //AddToOutput("SOURCE  " + "\"" + sourcePath + "\"");
        }

        private void Process_stabs_128(string[] stablineParts)  // LOCVAR
        {
            // All the stuff we're interested in is in the string field.  Chop it up.
            char[] splitChar = { ':', '=', ';' };
            string[] parts = stablineParts[0].Split(splitChar);

            if (parts.Length < 2)
            {
                AddToOutput("===== Invalid typedef: " + RebuildStabs(stablineParts));
                return;
            }

            // Here we detect and process lines that are vardefs, not typedefs
            // .stabs "bob:1",128,0,0,-4
            if (char.IsDigit(parts[1][0]))
            {
                // .stabs "max:16",128,0,0,-16
                string typeNum = parts[1];
                string typeInfo = GetTypeName(typeNum);
                string accessStr = "FP(" + stablineParts[4] + ")";
               
                string varData = parts[0] + " (" + typeInfo + ") @ " + accessStr;

                if (LexLevel > 1)
                {
                    AddToVisibleVarsList(LexLevel, varData);
                    return;
                }

                string visibility = "[" + LexLevel.ToString() + "] ";
                AddToOutput("LOCVAR " + CurrentProc + visibility + varData);
                return;
            }

            if (parts[1].Length < 2)
            {
                AddToOutput("===== Invalid typedef: " + RebuildStabs(stablineParts));
                return;
            }

            ExtractEmbeddedTypeDefsFrom_128(stablineParts[0]);
            return;
        }

        private void Process_stabs_32(string[] stablineParts)   // GLOBVAR
        {
            char[] splitChar = { ':' };
            string[] parts = stablineParts[0].Split(splitChar);
            if (parts.Length != 2 || parts[1].Length < 2 || !parts[1].StartsWith("G"))
            {
                AddToOutput("===== invalid global def: " + RebuildStabs(stablineParts));
                return;
            }
            string typenum = parts[1].Remove(0, 1);
            if (!TypeDefListHas(typenum))
            {
                AddToOutput("===== undefined type in global def: " + RebuildStabs(stablineParts));
                return;
            }
            string mangledSymbol = ConvertSymbolToMangledForm(parts[0]);
            AddToOutput("GLOBVAR " + parts[0] + " (" + GetTypeName(typenum) +
                                  ") @ " + LocationOf(mangledSymbol));
            return;
        }

        private void Process_stabs_36(string[] stablineParts)   // function name
        {
            // Handle ...
            //    .stabs "main:F15",36,0,0,C_main

            char[] splitChar = { ':' };
            string[] parts = stablineParts[0].Split(splitChar);
            CurrentProc = parts[0];

            LexLevel = 0;

            // Now we check to see if this function has a frame.  We do that by finding
            // the line in the .lst file where the function starts and look at the next line
            // to see if it has jmp #NEWF in it.  If so, it has a frame, otherwise it doesn't.

            string funcNameStr = ConvertSymbolToMangledForm(CurrentProc) + " ' " +
                "<symbol:" + CurrentProc + ">";

            for (int indexIntoLstFile = 0; indexIntoLstFile < ListFile.Count; indexIntoLstFile++)
            {
                if (ListFile[indexIntoLstFile].EndsWith(funcNameStr))
                {
                    if (ListFile[indexIntoLstFile + 1].EndsWith("jmp #NEWF") || ListFile[indexIntoLstFile + 1].Contains("long I32_NEWF"))
                        AddToOutput("FRAMED  " + CurrentProc);
                    else
                        AddToOutput("NOFRAME " + CurrentProc);  
                    return;
                }
            }
        }

        private void Process_stabs_38(string[] stablineParts)   // => stabs 40
        {
            // Handles ... (an initialized static)
            //   .stabs "Ralph:V4",38,0,0,C_doW_ork_R_alph_L000022

            // We can simply call the routine for uninitialized static as the debugger
            // doesn't care about that.  That's the compiler's job.
            Process_stabs_40(stablineParts);
        }

        private void Process_stabs_40(string[] stablineParts)   // LOCVAR or GLOBFILE
        {
            // Handles ... (an uninitialized static)
            //   .stabs "Judy:V20",40,0,0,C_main_J_udy_L000007
            // We will do lookups based on last field (C_main_J_udy_L000007)
            // We do it this way to deal properly with statics.

            char[] splitChar = { ':' };
            string[] parts = stablineParts[0].Split(splitChar);

            // All local var defs must be of the form...  <var name>:<type designator>
            // Skip all lines that don't have this form.
            if (parts.Length != 2)
            {
                AddToOutput("===== Invalid stabs line: " + RebuildStabs(stablineParts));
                return;
            }

            string accessStr = "TBD";
            string typeNum = "";
            string typeInfo = "???";

            // .stabs "Judy:V17",40,0,0,C_main_J_udy_L000006  ... this should be a LOCVAR
            // .stabs "Judy:S17",40,0,0,C_main_J_udy_L000006  ... this should be a GLOBFILE
            char scopeChar = parts[1][0];

            typeNum = parts[1].Remove(0, 1);
            string baseType = GetTypeName(typeNum);
            typeInfo = "static " + baseType;

            // accessStr = LocationOf(parts[0]);
            accessStr = LocationOf(stablineParts[4]);

            string varData = parts[0] + " (" + typeInfo + ") @ " + accessStr;

            if (LexLevel > 1)
            {
                AddToVisibleVarsList(LexLevel, varData);
                return;
            } 
            
            string visibility = "[" + LexLevel.ToString() + "] ";

            if ( scopeChar == 'V' )
                AddToOutput("LOCVAR " + CurrentProc + visibility + varData);
            else if ( scopeChar == 'S' )
                AddToOutput("GLOBFILE " + varData);
            else
                AddToOutput("===== undefined scopeChar in stabs 40: " + RebuildStabs(stablineParts));
        }

        private void Process_stabs_64(string[] stablineParts)   // LOCVAR
        {
            // Handles ...
            //    .stabs "xin:P1",64,0,4,2
            //    .stabs "x:r1",64,0,4,15

            char[] splitChar = { ':' };
            string[] parts = stablineParts[0].Split(splitChar);

            // Here we deal with LCC little quirk re: doubles held in registers.
            int regNum;
            int.TryParse(stablineParts[4], out regNum);
            if (regNum > 31) 
                regNum = regNum - 32;


            string typeNum = parts[1].Remove(0, 1);
            string typeInfo = GetTypeName(typeNum);
            string accessStr = "r" + regNum.ToString(); ;

            string varData = parts[0] + " (" + typeInfo + ") @ " + accessStr;

            if (LexLevel > 1)
            {
                AddToVisibleVarsList(LexLevel, varData);
                return;
            }

            string visibility = "[" + LexLevel.ToString() + "] ";
            AddToOutput("LOCVAR " + CurrentProc + visibility + varData);
        }
       
        private void Process_stabs_100(string[] stablineParts)  // ignored
        {
            // We simply ignore these.  We don't what they mean anyway
            //    .stabs "", 100, 0, 0,L___2e_2e_5cBobs_20Test_20Main_2ec_00_etext
            return;
        }

        private void Process_stabs_160(string[] stablineParts)  // LOCVAR (function parameters)
        {
            // Since this type involves function parameters, it must always occur a lex level 0, so we
            // do not have any need to add to VisibleVars list.

            // Handle parameters that are on the stack
            //   .stabs "Q2:p1",160,0,0,12

            char[] splitChar = { ':' };
            string[] parts = stablineParts[0].Split(splitChar);

            // All local var defs must be of the form...  <var name>:<type designator>
            // Skip all lines that don't have this form.
            if (parts.Length != 2)
            {
                AddToOutput("===== Invalid stabs line: " + RebuildStabs(stablineParts));
                return;
            }

            // .stabs "Q2:p1",160,0,0,12
            string typeNum = parts[1].Remove(0, 1);        // Get rid of p
            string typeInfo = GetTypeName(typeNum);
            string accessStr = "FP(" + stablineParts[4] + ")";

            string visibility = "[" + LexLevel.ToString() + "] ";
            AddToOutput("LOCVAR " + CurrentProc + visibility + parts[0] + " (" + typeInfo +
                                                  ") @ " + accessStr);
        }

        private void Process_stabn_0x44(string[] stablineParts) // LINENUM
        {
            // Line labels in stabs have -C_addA_toB_ stuff appended.
            // Here we remove that extra stuff to correspond with what is
            // in the listing file.

            string searchStr = StripProcNameFromLabel(stablineParts[3]);

            string varData = "";

            if (LexLevel > 1 )
            {
                for (int i = LexLevel - 2; i >= 0; i--)
                {
                    if ( VisibleVars.Count > i )
                        varData += VisibleVars[i];
                }
            }

            // Get rid of the trailing " | "
            char[] trimChars = { '|', ' ' };
            varData = varData.TrimEnd(trimChars);

            string procName = ExtractUnmangledProcNameFrom(stablineParts[3]);

            string loc = LocationOf(searchStr);

            if (WaitingForFirst0x44)
            {
                FirstLineLoc = loc;
                WaitingForFirst0x44 = false;
            }
            LastLineLoc = loc;

            AddToOutput("LINENUM " + stablineParts[2] + "[" + procName + "," + LexLevel.ToString() + "] @ " +
                                      loc + " " + varData);
        }

        private void Process_stabn_0xe0(string[] stablineParts) // change LexLevel (down)
        {
            // These are processed by ExtractProcedureRangesFromDebugFile()  (end of procedure lines)
            //   .stabn 0xe0,0,0,L___2e_2e_5cBobs_20Test_20Main_2ec_00_29-C_doW_ork
            LexLevel = int.Parse(stablineParts[2]);

            if (LexLevel > 0)
                VisibleVars[LexLevel - 1] = "";

            return;
        }

        private void Process_stabn_0xc0(string[] stablineParts) // change LexLevel (up)
        {
            // These are processed by ExtractProcedureRangesFromDebugFile() (start of procedure lines)
            //    .stabn 0xc0,0,0,L___2e_2e_5cBobs_20Test_20Main_2ec_00_24-C_doW_ork 

            LexLevel = int.Parse(stablineParts[2]) + 1;

            // Make sure that we extend the VisibleVars list to have entries (even if blank) for LexLevels 2 and
            // above.

            if (LexLevel > 1)
            {
                while (VisibleVars.Count < LexLevel - 1)
                {
                    VisibleVars.Add("");
                }
            }
            
            return;
        }

        private void Process_stabs_0x3c(string[] stablineParts) // ignored
        {
            // We don't use this one for anything..
            //   .stabs "lcc4_compiled.",0x3c,0,0,0
            return;
        }

        #region stabx support routines

        private void AddToVisibleVarsList(int lexLevel, string varData)
        {
            // Add variable visible at this lex level.  We maintain a list for each lex level
            // from 2 and above.

            int listIndex = lexLevel - 2;

            // Dynamically expand list as we encounter deeper lex levels.
            while (listIndex >= VisibleVars.Count)
                VisibleVars.Add("");

            VisibleVars[listIndex] = VisibleVars[listIndex] + varData + " | ";
        }

        private string ExtractUnmangledProcNameFrom(string s)
        {
            string ans = "";

            int procNamePos = s.LastIndexOf("-C_");

            if (procNamePos < 0) return "????";

            ans = s.Remove(0, procNamePos + 3);

            // Now we have to deal with "static" function names like sgsg27_4b5ba434_makemoves_L000275

            if (ans.Contains("_L"))
            {
                int pos = 0;
                pos = ans.LastIndexOf('_');
                if (pos > 0) ans = ans.Remove(pos);
                pos = ans.IndexOf('_');
                if (pos > 0) ans = ans.Remove(0, pos + 1);
                pos = ans.IndexOf('_');
                if (pos > 0) ans = ans.Remove(0, pos + 1);
            }

            return Unmangle(ans);
        }

        private string Unmangle(string s)
        {
            string ans = "";

            for (int i = 0; i < s.Length; i++)
            {
                if (char.IsUpper(s[i]))
                {
                    ans += s[i];
                    i++;
                }
                else
                {
                    ans += s[i];
                }
            }
            return ans;
        }

        #endregion

        #endregion

        private void AddToOutput(string s)
        {
            // Add a string to the DebugOutput string list.
            DebugOutput.Add(s);
        }

        private string ConvertSymbolToMangledForm(string symbol)
        {
            // This routine takes a bare symbol like  addAtoB  and 
            // produces  C_addA_toB_  which is the first key in .lst lines like
            //  	
            // Line 1039: 0ab4(0294):             ' C_exampleS_truct ' <symbol:exampleStruct>

            string answer = "C_";

            for (int i = 0; i < symbol.Length; i++)
            {
                answer += symbol[i];
                if (char.IsUpper( symbol[i] ) )
                    answer += '_';

            }

            return answer;
        }

        private string[] ParseStabs(string stabsLineIn)
        {
            // Here we parse a .stabs line into 5 strings.

            // Provide default answer in case we take an early exit because of an invalid
            // input line.
            string[] answer = { "", "", "", "", "" };

            string stub = stabsLineIn;

            // Here we make the critical assumption that in a .stabs line, comma and double quote are
            // always delimiters and never part of a field.
            char[] splitChar = { '"' };
            string[] parts = stub.Split(splitChar);

            // There should only be two double quotes, ergo only three 'parts'
            if (parts.Length != 3)
            {
                AddToOutput("===== Invalid input to ParseStabs():" + stabsLineIn);
                return answer;
            }

            // parts[0] contains .stabs  parts[1] is the string bracketed by the double quotes.
            answer[0] = parts[1];

            // parts[2] looks like ,0x64,0,0,0
            splitChar[0] = ',';
            parts = parts[2].Split(splitChar, StringSplitOptions.RemoveEmptyEntries);

            // There should be exactly four parts now because we suppressed the empty piece
            // that was due to the leading comma.
            if (parts.Length != 4)
            {
                AddToOutput("===== Invalid input to ParseStabs():" + stabsLineIn);
                return answer;
            }

            for (int i = 1; i < 5; i++) answer[i] = parts[i - 1];

            return answer;
        }

        private string[] ParseStabn(string stabnLineIn)
        {
            // Here we parse a .stabn into 4 strings.
            string[] answer = { "", "", "", "" };

            string stub = stabnLineIn.Remove(0, 7);  // Remove .stabn_

            // Now stub looks like 0x44,0,48,L___2e_2e_5cBobs_20Test_20Main_2ec_00_25-C_doW_ork  

            // Here we make the critical assumption that in a .stabn line,  a comma
            // is always a delimiter and never part of a field.
            char[] splitChar = { ',' };
            string[] parts = stub.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);

            // As there should have been exactly 3 commas in stub, we should now have 4 parts
            if (parts.Length != 4)
            {
                AddToOutput("===== Invalid input to ParseStabn():" + stabnLineIn);
                return answer;
            }

            for (int i = 0; i < 4; i++) answer[i] = parts[i];

            return answer;
        }

        private void ExtractSourcePathFromDebugFile()
        {
            // Source file info is held in .stabs 0x64 lines

            foreach (string s in DebugFile)
            {
                if (s.StartsWith(".stabs"))
                {
                    string[] stablineParts = ParseStabs(s);
                    if (stablineParts[1] == "0x64")
                    {
                        Process_stabs_0x64(stablineParts);
                    }
                }
            }
        }

        private bool TypeDefListHas(string typenum)
        {
            string searchStr = typenum + ":";
            foreach (string s in TypeDefs)
            {
                if (s.StartsWith(searchStr)) return true;
            }
            return false;
        }

        private string GetTypeName(string typenum)
        {
            string searchStr = typenum + ":";
            foreach (string s in TypeDefs)
            {
                if (s.StartsWith(searchStr))
                {
                    char[] splitChar = { ':' };
                    string[] parts = s.Split(splitChar);
                    return parts[1];
                }
            }
            return "";
        }

        private string[] DivideStringAt(string s, char divChar)
        {
            // This is a very useful string routine for parsing .stabs lines that
            // have embedded type definitions.

            // It divides an input string into two strings at the first occurrence
            // of divChar.  If the input string is  Tom Tom,alice  and the divChar is ,
            // Tom Tom would be returned in ans[0] and ,alice  in ans[1]
            // Note that ans[0] + ans[1] = s  (no characters are lost).

            string[] ans = { "", "" };

            // divideSpot get the index into s of the first occurrence of divChar.
            int divideSpot = s.IndexOf(divChar);

            if (divideSpot == -1)
            {
                // This is the case where the divChar was not present.  If the string is
                // undividable, it is returned intact in ans[0]
                ans[0] = s;
                ans[1] = "";
                return ans;
            }
            else
            {
                ans[0] = s.Remove(divideSpot);
                ans[1] = s.Remove(0, divideSpot);
            }
            return ans;
        }

        private void AddType(string typeNum, string def)
        {
            int typeValue;
            int.TryParse(typeNum, out typeValue);

            TypeDefs.Add(typeNum + ":" + def);

            if (ShowNewTypeDefs && typeValue > MaxStandardTypeValue)
            {
                AddToOutput("TYPEDEF " + typeNum + " " + def);
            }

            if (ShowStdTypeDefs && typeValue <= MaxStandardTypeValue)
            {
                AddToOutput("TYPEDEF " + typeNum + " " + def);
            }
        }

        private string ExtractTypeNumberFromEnd(string s)
        {
            // This routines extracts the trailing digits from the input string and returns
            // them as a string.
            int digitsPos;
            for (digitsPos = s.Length - 1; digitsPos >= 0; digitsPos--)
            {
                if (char.IsDigit(s[digitsPos])) continue;
                break;
            }
            return s.Remove(0, digitsPos + 1);
        }

        private string ExtractEmbeddedTypeDefsFrom_128(string s)
        {
            try
            {
                char[] splitChar = { '=' };
                string sCopy = s;
                string typeNum;
                string[] subparts;

                // This routine scans s for embedded type definitions.  It issues appropriate
                // TYPEDEF statements and then removes the embedded typedef from s
                // and returns the remainder.  Example of s (split into two lines for ease of reading) ...

                //   aStruct:T20=s52numRocks:1,0,32;radius:4,32,32;inChar:21=*2,64,32;
                //   interior:22=ar1;0;2;19,96,192;exterior:19,288,64;Baby:18,352,64;;

                // This routine needs to find the type defined at =s and the type at =*  and the one at =ar1.
                // The LCC compiler appears to only embed pointer definitions and array definitions within a
                // struct type definition.  If you try to define a struct within a struct, LCC provides a separate
                // .stabs line for the otherwise embedded struct definition.
                // The s return will be reduced to just "aStruct:T20".

                string structName;
                subparts = DivideStringAt(sCopy, ':');
                structName = subparts[0];

            recurse:

                splitChar[0] = '=';
                string[] parts = sCopy.Split(splitChar);

                // parts[] was built by splitting sCopy at = (the places where new types
                // are being defined.

                // There's nothing to do if no = was present.  We're done.
                if (parts.Length == 1) return sCopy;

                // Work backwards. i.e., figure out the last parts entry first
                int lastPartIndex = parts.Length - 1;
                int precPartIndex = lastPartIndex - 1;

                typeNum = ExtractTypeNumberFromEnd(parts[precPartIndex]);

                char typeBeingDefined = parts[lastPartIndex][0];

                // Here we make a special case to deal with...
                //  .stabs "void:t15=15",128,0,0,0   Note the missing r  Other standard types look like ...
                //  .stabs "signed char:t9=r1;D;D;",128,0,0,0
                if (char.IsDigit(typeBeingDefined)) typeBeingDefined = 'r';

                if (typeBeingDefined == 'r')
                {
                    // Handle ...
                    // .stabs "long double:t5=r1;4;0;",128,0,0,0

                    string def = structName;
                    AddType(typeNum, def);
                    return parts[1];
                }

                if (typeBeingDefined == 'f')
                {
                    // Handle
                    //  .stabs ":t28=ar1;0;4;29=*30=f31=*1",128,0,0,0
                    // parts[lastPartIndex] will hold f31

                    subparts = DivideStringAt(parts[lastPartIndex], ',');
                    subparts[0] = subparts[0].Remove(0, 1);

                    string def = "func[" + GetTypeName(subparts[0]) + "]";

                    AddType(typeNum, def);

                    // Return parts[lastPartIndex] without the function definition
                    parts[lastPartIndex] = subparts[1];
                    goto reassemble_sCopy;
                }

                if (typeBeingDefined == 'e')
                {
                    // Handle enum ...
                    //    .stabs "WEEKDAY:T16=emon:0,tues:1,wed:2,thur:3,fri:4",128,0,0,0
                    // We want to emit  TYPEDEF 16 enum[WEEKDAY]

                    string def = "enum[" + structName + "]";

                    AddType(typeNum, def);

                    parts[lastPartIndex] = "";
                    goto reassemble_sCopy;
                }

                if (typeBeingDefined == 'a')
                {
                    // Handle embedded array definition.

                    subparts = DivideStringAt(parts[lastPartIndex], ',');

                    // Handles a standalone array definition as a special case (there is no , in such a case)
                    if (subparts[0] == "") subparts[0] = subparts[1];

                    // ar1;0;2;17  is the form of subpart[0]

                    splitChar[0] = ';';
                    string[] aparts = subparts[0].Split(splitChar, StringSplitOptions.RemoveEmptyEntries);

                    int arraySize;
                    int.TryParse(aparts[2], out arraySize);
                    arraySize++;

                    string def = "array[" + arraySize.ToString() + "](" + GetTypeName(aparts[3]) + ")";
                    AddType(typeNum, def);

                    // Return parts[lastPartIndex] without the array definition stuff.
                    parts[lastPartIndex] = subparts[1];

                    goto reassemble_sCopy;
                }

                if (typeBeingDefined == '*')
                {
                    // Handle embedded pointer definition
                    //   subpart[0] has the form... *2,64,32;

                    // The next statement picks off *2
                    subparts = DivideStringAt(parts[lastPartIndex], ',');

                    subparts[0] = subparts[0].Remove(0, 1);  // Remove the * to leave 2

                    string def = "*" + GetTypeName(subparts[0]);
                    AddType(typeNum, def);

                    // Return parts[lastPartIndex] without the pointer definition stuff
                    parts[lastPartIndex] = subparts[1];

                    goto reassemble_sCopy;
                }

                if (typeBeingDefined == 's' || typeBeingDefined == 'u')
                {
                    // Handle structure and union type definition
                    // At this point, all the subparts (except 0) look like  name:1,0,32
                    // parts[lastPartsIndex] has a leading s and a string of digits that give the size of the
                    // structure.  We want to remove those parts.

                    parts[lastPartIndex] = parts[lastPartIndex].Remove(0, 1);  // Remove the s (or u)
                    while (char.IsDigit(parts[lastPartIndex][0])) parts[lastPartIndex] = parts[lastPartIndex].Remove(0, 1);

                    splitChar[0] = ';';
                    subparts = parts[lastPartIndex].Split(splitChar, StringSplitOptions.RemoveEmptyEntries);

                    string type = "";

                    for (int i = 0; i < subparts.Length; i++)
                    {
                        char[] splitChars = { ':', ',' };
                        string[] sparts = subparts[i].Split(splitChars);
                        type += " " + sparts[0] + "("; // RLA 1/22/2010  added space after ( to make structs more readable

                        // RLA 3/19/2010 The following change was made to support bit-fields and unions by including
                        // bit offset and bit size values in the .dbg file for use by the Variable Display/Modify routine.
                        //type += GetTypeName(sparts[1]) + ")";  // Previously
                        type += GetTypeName(sparts[1]) + "." + sparts[2] + "." + sparts[3] + ")";

                    }

                    string defName = "struct";
                    if (typeBeingDefined == 'u')
                        defName = "union";

                    // RLA 1/22/2010  added space after ( to make structs more readable
                    string def = defName + "[" + structName + "]{ " + type + "}"; 
                    AddType(typeNum, def);

                    parts[lastPartIndex] = "";

                    goto reassemble_sCopy;
                }

                // If this point is reached, we have found an embedded typedef that we don't
                // know how to handle.

                AddToOutput("===== unknown embedded typedef in: " + s);
                return s;

            reassemble_sCopy:

                // Put sCopy back together.  The handlers above will have modified the final parts[]
                // string so that the = must be left out when the parts[] is added back on to sCopy.
                sCopy = parts[0];

                // This for loop is designed to add back the equal sign between all parts except
                // the last two (because we have stripped the type def stuff from the beginning
                // of the the last parts element, it must be simply concatenated without an = 
                for (int i = 1; i < parts.Length - 1; i++)
                {
                    sCopy += ("=" + parts[i]);
                }
                sCopy += parts[parts.Length - 1];
                goto recurse;
            }
            catch (Exception err)
            {
                AddToOutput("===== exception (" + err.Message + ") processing " + s);
                return s;
            }
        }

        private string RebuildStabs(string[] stablineParts)
        {
            // This routine undoes the parse of a .stabs line to reconstruct the original string
            string answer = ".stabs \"" + stablineParts[0] + "\"";
            for (int i = 1; i < stablineParts.Length; i++)
            {
                answer += ',' + stablineParts[i];
            }
            return answer;
        }

        private string LocationOf(string searchStr)
        {
            string ans;

            if (!SymbolTable.TryGetValue(searchStr, out ans)) ans = "???";
            return ans;
        }

        private string StripProcNameFromLabel(string label)
        {
            char[] splitChar = { '-' };
            string[] parts = label.Split(splitChar);
            return parts[0];
        }

        private string ExtractSourceFileName(string s)
        {
            // We assume that the relevant .lst line ends in the text held in FileNameTerminationText.
            // This routine is only called with an s that has that termination.
            // This routine extracts and returns pathname of the source file.

            int nameStrIndex = s.IndexOf("L__");
            if (nameStrIndex < 1)
            {
                return "Invalid input: " + s;
            }

            string s2 = s.Remove(0, nameStrIndex + 3);                    // Remove L__ 
            s2 = s2.Remove(s2.Length - FileNameTerminationText.Length); // ..and terminator

            // What remains should not contain underscore characters.  If they do,
            // treat the first 2 characters as a hex number and replace the 2 characters with
            // the equivalent ascii character.  At the end, concatenate the parts.  There is
            // no need to add .c because that is encoded in the string as _2ec

            char[] splitChar = { '_' };
            string[] parts = s2.Split(splitChar);

            string answer = parts[0];
            try
            {
                string hexStr = "";
                // If this point is reached, we have some non alphanum chars in the filename.
                for (int i = 1; i < parts.Length; i++)
                {
                    if (parts[i].Length > 2)
                        hexStr = parts[i].Remove(2);
                    else
                        hexStr = parts[i];
                    int num = Int32.Parse(hexStr, System.Globalization.NumberStyles.HexNumber);
                    answer += (char)num + parts[i].Remove(0, 2);
                }
                return answer;
            }
            catch
            {
                return "Invalid input: " + s;
            }
        }

        //private void ExtractProcedureRangesFromDebugFile()
        //{
        //    string procName = "";
        //    string rangeBeg = "";
        //    string rangeEnd = "";

        //    foreach (string s in DebugFile)
        //    {
        //        string[] stablineParts = { };

        //        // We need to pick up the procedure name as we iterate throught the file so
        //        // that we can properly label the RANGE.  That data is held in .stabs lines as...
        //        // .stabs "doWork:F15",36,0,0,C_doW_ork

        //        if (s.StartsWith(".stabs"))
        //        {
        //            stablineParts = ParseStabs(s);

        //            char[] splitChar = { ':' };
        //            string[] parts = stablineParts[0].Split(splitChar);

        //            if (parts.Length != 2) continue;

        //            if (stablineParts[1] == "36")
        //            {
        //                procName = parts[0];
        //            }
        //            continue;
        //        }
        //        else
        //        {
        //            if (s.StartsWith(".stabn"))
        //            {
        //                stablineParts = ParseStabn(s);

        //                // Here we're looking for...
        //                // .stabn 0xc0,0,0,L___2e_2e_5cBobs_20Test_20Main_2ec_00_23-C_doW_ork
        //                if (stablineParts[0] == "0xc0")
        //                {
        //                    if (stablineParts[1] == "0" && stablineParts[2] == "0")
        //                    {
        //                        // Get rid of -C_doW_ork in search string.
        //                        string searchStr = StripProcNameFromLabel(stablineParts[3]);
        //                        rangeBeg = LocationOf(searchStr);
        //                    }
        //                    continue;
        //                }

        //                // Here we're looking for...
        //                // .stabn 0xe0,0,0,L___2e_2e_5cBobs_20Test_20Main_2ec_00_28-C_doW_ork
        //                if (stablineParts[0] == "0xe0")
        //                {
        //                    if (stablineParts[1] == "0" && stablineParts[2] == "0")
        //                    {
        //                        // Get rid of -C_doW_ork in search string.
        //                        string searchStr = StripProcNameFromLabel(stablineParts[3]);
        //                        rangeEnd = LocationOf(searchStr);
        //                        AddToOutput("RANGE  " + procName + " " + rangeBeg + ".." + rangeEnd);
        //                    }
        //                    continue;
        //                }
        //            }
        //        }
        //    }
        //}

        private void ProcessDebugFileLineByLine()
        {
            VisibleVars.Clear();
            WaitingForFirst0x44 = true;
            FirstLineLoc = LastLineLoc = "";

            foreach (string s in DebugFile)
            {
                if (s.StartsWith(".stabs"))
                {
                    string[] stablineParts = ParseStabs(s);
                    string sType = stablineParts[1];

                    if (sType == "32") Process_stabs_32(stablineParts);
                    else if (sType == "36") Process_stabs_36(stablineParts);
                    else if (sType == " 100") Process_stabs_100(stablineParts);
                    else if (sType == "128") Process_stabs_128(stablineParts);
                    else if (sType == "38") Process_stabs_38(stablineParts);
                    else if (sType == "40") Process_stabs_40(stablineParts);
                    else if (sType == "64") Process_stabs_64(stablineParts);
                    else if (sType == "0x64") Process_stabs_0x64(stablineParts);
                    else if (sType == "0x84") Process_stabs_0x84(stablineParts);
                    else if (sType == "0x3c") Process_stabs_0x3c(stablineParts);
                    else if (sType == "160") Process_stabs_160(stablineParts);
                    else AddToOutput("===== Unexpected .stabs type: " + sType);
                    continue;
                }

                if (s.StartsWith(".stabn"))
                {
                    string[] stablineParts = ParseStabn(s);
                    string nType = stablineParts[0];

                    if (nType == "0xe0") Process_stabn_0xe0(stablineParts);
                    else if (nType == "0xc0") Process_stabn_0xc0(stablineParts);
                    else if (nType == "0x44") Process_stabn_0x44(stablineParts);
                    else AddToOutput("===== Unexpected .stabn type: " + nType);
                    continue;
                }

                AddToOutput("===== Invalid stab line: " + s);
            }
        }

        private void ProcessDebugFile()
        {
            TypeDefs.Clear();

            ProcessDebugFileLineByLine();
            AddToOutput("RANGE " + FirstLineLoc + ".." + LastLineLoc);
        }

        private void ProcessSourceFileList(List<string> debugPaths)
        {
            foreach (string sourcePathname in SourceFileList)
            {
                // We are expecting the .debug files to have the same name as the source file,
                // but be located in the directory list (debugPaths) supplied by the user.  The source files
                // are typically located elsewhere, so sourcePathname will often have path info
                // as well that we have to remove.

                char[] splitChar = { '\\' };

                if (Linux) splitChar[0] = '/';

                string[] parts = sourcePathname.Split(splitChar);

                // The last parts entry should contain the bare filename.
                string sourceFilename = parts[parts.Length - 1];  // Path info removed.

                string debugFileName = "";
                // Compose debug filename by removing the c from sourcefilename.c replacing
                // it with debug extension.
                try
                {
                    string noExtFilename = sourceFilename.Remove(sourceFilename.Length - 2);
                    debugFileName = noExtFilename + ".debug";
                }
                catch
                {
                    AddToOutput("===== Invalid source filename: " + sourceFilename);
                    return;
                }

                // Now need to see if the .debug file can found among the supplied directories.
                bool foundDebugFile = false;
                string fullDebugFileName = "";

                // Look for the debug file in each of the supplied directories
                for (int i = 0; i < debugPaths.Count; i++)
                {
                    // Here we can compose the full path easily because earlier we made
                    // sure that debugPaths all end in / or \ as appropriate.
                    fullDebugFileName = debugPaths[i] + debugFileName;

                    // Lokk for the file.
                    FileInfo file = new FileInfo(fullDebugFileName);

                    foundDebugFile = file.Exists;
                        
                    if (foundDebugFile) break;
                }

                if (! foundDebugFile )
                {
                    AddToOutput("===== Halting processing because couldn't find: " + debugFileName);
                    PostProcessDebugOutput();
                    return;
                }

                // Read the selected file
                using (StreamReader sr = new StreamReader(fullDebugFileName))
                {
                    DebugFile.Clear();
                    DebugOutput.Clear();

                    string theTotalText = "";
                    while (!sr.EndOfStream)
                    {
                        string aLine = sr.ReadLine();
                        DebugFile.Add(aLine);
                        theTotalText += aLine + "\r\n";
                    }
                }

                // .stabs lines can be "continued".  That disrupts the logic of most of
                // the "extraction" routines that are called by ProcessDebugFile(), so we
                // will pre-process the debug file to gather up such continuations back into single lines.
                ReglueDebugFile();

                // Here we call a routine that reorders DebugFile so that all variable definitions are
                // more usefully enclosed in 0xc0  0xe0 pairs.  We also process stabs 128 lines that
                // contain nested struc definitions to un-nest them and get them "tagged" properly
                ReorderDebugFile();

                //// Write reordered file (for diagnostic use)
                //using (StreamWriter sw = new StreamWriter(fullDebugFileName + "r"))
                //{
                //    foreach (string s in ReorderedDebugFile)
                //    {
                //        sw.Write(s + "\r\n");
                //    }
                //}

                // Copy the reordered file back into DebugFile
                DebugFile.Clear();
                foreach (string s in ReorderedDebugFile)
                {
                    DebugFile.Add(s);
                }

                // This is kind of hidden, but is where each debug file is processed.
                ProcessDebugFile();

                // Here is where we post-process the output produced from the current debug file.
                // This adds to OutputString for use in populating the tbxBottom and later for
                // writing to a file.
                PostProcessDebugOutput();
            }
        }

        private void ReorderDebugFile()
        {
            int i;

            ReorderedDebugFile.Clear();
            for( i = 0; i < DebugFile.Count; i++ )
            {
                if ( DebugFile[i].StartsWith( ".stabn 0xc0" ) )
                {
                    int insertPoint = FindWhere0xc0ShouldBePut();
                    ReorderedDebugFile.Insert(insertPoint+1, DebugFile[i]);
                    FindMatching0xe0(i);
                }
                else if (DebugFile[i].EndsWith( ",128,0,0,0" ) )
                {
                    UnnestStabs128(i);
                }
                else{
                    if (DebugFile[i] == "moved") continue;
                    ReorderedDebugFile.Add(DebugFile[i]);
                }
            }
        }

        private void FindMatching0xe0(int start)
        {
            string[] c0parts = ParseStabn(DebugFile[start]);
            for (int i = start + 1; i < DebugFile.Count; i++)
            {
                if (DebugFile[i].StartsWith(".stabn 0xe0"))
                {
                    string[] e0parts = ParseStabn(DebugFile[i]);
                    if (c0parts[2] == e0parts[2])
                    {
                        // We have found the matching 0xe0
                        // Now we work backwards.  For each line in DebugFile
                        // that is not a stabn line, we add it to ReorderedDebugFile
                        // and delete it from DebugFile.  We return when any stabn
                        // line is encountered.
                        int insertPoint = ReorderedDebugFile.Count;
                        for (i = i - 1; i > 0; i--)
                        {
                            if ( DebugFile[i].StartsWith(".stabn")) return;
                            //ReorderedDebugFile.Add(DebugFile[i]);
                            ReorderedDebugFile.Insert(insertPoint, DebugFile[i]);
                            DebugFile[i] = "moved";
                        }
                    }
                }
            }
        }

        private int FindWhere0xc0ShouldBePut()
        {
            int i;
            for (i = ReorderedDebugFile.Count - 1; i > 0; i--)
            {
                if ( ReorderedDebugFile[i].StartsWith(".stabn") ) return i;
                if ( ReorderedDebugFile[i].Contains(":F") ) return i;
                continue;
            }
            return i;
        }

        private void UnnestStabs128(int debugFileIndex)
        {
            string s128 = DebugFile[debugFileIndex];

        recurse:

            // Find first occurrence of =s in s128. If not found, s128 is not
            // a struct definition, so we just add s128 to the output and return.
            int posOfEq = s128.IndexOf("=s");
            if (posOfEq < 0)
            {
                posOfEq = s128.IndexOf("=u");
                if (posOfEq < 0)
                {
                    ReorderedDebugFile.Add(s128);
                    return;
                }
            }

            // If this point is reached, we have a struct or a union definition.

            // Now we need to scan s128 from posOfEq to end looking for a second =s or =u
            // sequence.  If we don't find it, we add s128 to ReorderedDebugFile list and exit
            // because it does not contain a nested strut definition,
            // otherwise we have at least one nested struct definition that we need to extract.

            int newPosOfEq = s128.IndexOf("=s", posOfEq + 2);
            if (newPosOfEq < 0)
            {
                newPosOfEq = s128.IndexOf("=u", posOfEq + 2);
                // We don't have a nested situation.  Just add s128 to the
                // output list and return.
                if (newPosOfEq < 0)
                {
                    ReorderedDebugFile.Add(s128);
                    return;
                }
            }

            // If this point is reached, we have found a nested struct.  Now scan for the
            // sequence ;; or =s or =u.

        tryAgain:

            int semisPos = newPosOfEq+2;

            for (int k = semisPos; k < s128.Length-1; k++)
            {
                if (s128[k] == ';' && s128[k + 1] == ';')
                {
                    // We have found the matching ;; to the =s or =u  Copy the characters
                    // that comprise the simple unnested struct definition
                    string stub = "";
                    for (int kk = newPosOfEq; kk < k + 2; kk++)
                        stub += s128[kk];

                    // Get the typeNum string by scanning backwards from newPosOfEq
                    // until a non-digit is found.
                    string typeNumStr = "";
                    for (int kk = newPosOfEq - 1; kk > 0; kk--)
                    {
                        if (char.IsDigit(s128[kk]))
                        {
                            typeNumStr = s128[kk] + typeNumStr;
                            continue;
                        }
                        break;
                    }

                    // Remove stub from s128 and recurse
                    s128 = s128.Remove(newPosOfEq, stub.Length);
                    ProcessUnnestedStruct(stub, typeNumStr, debugFileIndex);
                    goto recurse;
                }
                if (s128[k] == '=' && ( (s128[k + 1] == 's') || (s128[k+1] == 'u')) )
                {
                    // We have found a deeper nested =s or =u sequence.  Start over
                    newPosOfEq = k;
                    goto tryAgain;
                }
            }
            // Only an error in the stabs line format will let us reach this point

        }

        private void ProcessUnnestedStruct(string stub, string typeNumStr, int debugFileIndex)
        {
            string structName = FindStructName(typeNumStr, debugFileIndex);

            string newStabsLine = ".stabs \"" + structName + ":t" + typeNumStr + stub + "\",128,0,0,0";
            ReorderedDebugFile.Add(newStabsLine);
        }

        private string FindStructName(string typeNumStr, int debugFileIndex)
        {
            char[] splitChars = { ':', '"' };
            for (int i = debugFileIndex + 1; i < DebugFile.Count; i++)
            {
                if (DebugFile[i].EndsWith( typeNumStr + "\",128,0,0,0"))
                {
                    string[] parts = DebugFile[i].Split(splitChars);
                    return parts[1];
                }
            }
            return "";
        }

        private void WriteOutputToDbgFile()
        {
            // We are going to write the OutputString to a .dbg file.  It is to go in the
            // same directory as the listing file, so we remove the trailing .lst from ListFilePath
            // and append .dbg to get a full pathname of where to write the output.
            string dbgPath = ListFilePath.Remove(ListFilePath.Length - 3, 3);

            dbgPath += "dbg";

            // Now we're ready to write the file.
            // Read the selected file
            using (StreamWriter sw = new StreamWriter(dbgPath))
            {
                sw.Write(OutputString);
            }
        }

        private string LocvarProcname(string s)
        {
            // This routine extracts the procedure name that a LOCVAR is in.  This
            // used just tp "pretty print" the output by putting a blank line between
            // blocks of LOCVAR lines.
            char[] splitChars = { ' ', '[' };   // Now the procname can be split off at the first space.
            string[] parts = s.Split(splitChars);
            return parts[1];
        }

        private void ProcessSourceLineNumToOutputString()
        {
            foreach (string s in DebugOutput)
            {
                if (s.StartsWith("LINENUM") || s.StartsWith("INCSRC"))
                {
                    if ( s.StartsWith("INCSRC"))
                    {
                        OutputString += NewLine;
                        OutputString += s + NewLine;
                        OutputString += NewLine;
                    }
                    else
                    {
                        OutputString += s + NewLine;
                    }
                }
            }
        }
        private void FromDebugOutputToOutputString(string lineHeader)
        {
            bool found = false;

            bool doingLocVar = lineHeader.StartsWith("LOCVAR");
            bool doingSource = lineHeader.StartsWith("SOURCE");

            string currentProcName = "";

            foreach (string s in DebugOutput)
            {
                if (s.StartsWith(lineHeader))
                {
                    if (doingLocVar)
                    {
                        string newProcname = LocvarProcname( s );
                        if (!currentProcName.Equals(newProcname))
                        {
                            // We've had a change of procname.  Emit a blank line.
                            currentProcName = newProcname;
                            OutputString += NewLine;
                        }
                    }
                    // Output a blank line before the first line of this type of line.
                    if (!found && !doingLocVar) OutputString += NewLine;

                    // We assume that there can be only one SOURCE line.
                    if (doingSource)
                    {
                        OutputString += s + "  [" + FirstLineLoc + ".." + LastLineLoc + "]" + NewLine;
                        return;
                    }

                    OutputString += s + NewLine;
                    found = true;
                }
            }
            return;
        }

        private void PostProcessDebugOutput()
        {
            FromDebugOutputToOutputString("RELOC"  );
            FromDebugOutputToOutputString("SOURCE" );
            FromDebugOutputToOutputString("====="  );
            FromDebugOutputToOutputString("FRAMED" );
            FromDebugOutputToOutputString("NOFRAME");
            FromDebugOutputToOutputString("TYPEDEF");
            FromDebugOutputToOutputString("GLOBVAR");
            FromDebugOutputToOutputString("GLOBFILE");
            FromDebugOutputToOutputString("LOCVAR" );
            //FromDebugOutputToOutputString("LINENUM");
            ProcessSourceLineNumToOutputString();
        }

        private void ReglueDebugFile()
        {
            List<string> workList = new List<string>();

            for (int i = 0; i < DebugFile.Count; i++)
            {
                string line = DebugFile[i];

                if (line.StartsWith(".stabn"))
                {
                    workList.Add(line);
                    continue;
                }
                string[] initialParts = ParseStabs(line);
                if (initialParts[0].EndsWith("\\\\"))
                {
                    // Remove the \\
                    initialParts[0] = initialParts[0].Remove(initialParts[0].Length - 2, 2);
                getContinuation:
                    i++;
                    string nextLine = DebugFile[i];
                    string[] addedParts = ParseStabs(nextLine);
                    if (addedParts[0].EndsWith("\\\\"))
                    {
                        addedParts[0] = addedParts[0].Remove(addedParts[0].Length - 2, 2);
                        initialParts[0] += addedParts[0];
                        goto getContinuation;
                    }
                    else
                    {
                        initialParts[0] += addedParts[0];
                        string fixedLine = ".stabs \"" + initialParts[0] + "\","
                            + initialParts[1] + ","
                            + initialParts[2] + ","
                            + initialParts[3] + ","
                            + initialParts[4];
                        workList.Add(fixedLine);
                    }
                }
                else
                {
                    workList.Add(line);
                }
            }
            DebugFile.Clear();
            DebugFile = workList;
            DebugOutput.Clear();
        }

        #endregion

    }
}
