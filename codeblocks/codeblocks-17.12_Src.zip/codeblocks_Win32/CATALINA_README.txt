Using the source files
======================

These files implement Catalina support within the Code::Blocks compiler and 
scriptedwizard plugins.

They are for use with Code::Blocks 17.12 only.

To use them, first download and install Code::Blocks and make sure you can
build it (unmodified) on your platform.

Them copy all the enclosed files to the top level directory for Code::Blocks
version 17.12. This will overwrite some existing Code::Blocks files, and add 
some new ones.

Then rebuild Code::Blocks. 


Using the default.conf file
===========================

Under Windows, the default.conf file should be placed in your codeblock 
AppData folder, which is usually in 
    C:\Users\<UserName>\AppData\Roaming\codeblocks\ 

Note that you must have run codeblocks at least once for it to create this
folder!

