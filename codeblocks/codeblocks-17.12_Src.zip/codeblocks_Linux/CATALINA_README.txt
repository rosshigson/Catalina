Using the source files
======================

These files implement Catalina support within the Code::Blocks compiler and 
scriptedwizard plugins.

They are for use with Code::Blocks 17.12 only.

To use them, first download and install Code::Blocks and make sure you can
build it (unmodified) on your platform.

Them copy all the enclosed files to the top level directory for Code::Blocks
version 17.12. This will overwrite some existing Code::Blocks files, and add 
some new ones.

Then rebuild Code::Blocks. 


Using the default.conf file
===========================

The default.conf.Linux file should be placed in your codeblocks configuration 
folder, which may be in 
   ~/.codeblocks 
or 
   ~/.config/.codeblocks

Note that you must have run codeblocks at least once for it to create the
folder!

