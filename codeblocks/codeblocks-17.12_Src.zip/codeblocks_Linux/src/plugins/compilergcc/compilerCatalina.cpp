/*
 * This file is part of the Code::Blocks IDE and licensed under the GNU General Public License, version 3
 * http://www.gnu.org/licenses/gpl-3.0.html
 *
 */

#include <sdk.h>
#include "compilerCatalina.h"
#include <wx/intl.h>
#include <wx/regex.h>
#include <wx/config.h>
#include <wx/fileconf.h>
#include <wx/msgdlg.h>

CompilerCatalina::CompilerCatalina()
    : Compiler(_T("Catalina C Compiler"), _T("catalina"))
{
    m_Weight = 5;
    Reset();
}

CompilerCatalina::~CompilerCatalina()
{
    //dtor
}

Compiler * CompilerCatalina::CreateCopy()
{
    Compiler* c = new CompilerCatalina(*this);
    return c;
} // end of CreateCopy

void CompilerCatalina::Reset()
{
    m_Options.ClearOptions();
    LoadDefaultOptions(GetID());

    LoadDefaultRegExArray();

    m_CompilerOptions.Clear();
    m_LinkerOptions.Clear();
    m_LinkLibs.Clear();
    m_CmdsBefore.Clear();
    m_CmdsAfter.Clear();

}

AutoDetectResult CompilerCatalina::AutoDetectInstallationDir()
{
    // use environment variable PATH if set
    wxString pathValues;
    AutoDetectResult ret;
    wxString sep = wxFileName::GetPathSeparator();
    wxGetEnv(_T("LCCDIR"), &pathValues);
    if (pathValues.IsEmpty())
    {
    if (platform::windows)
        m_MasterPath = _T("C:\\Program Files (x86)\\Catalina");
        wxString BinPath = m_MasterPath + sep + _T("bin");
        ret = wxFileExists(BinPath + sep + m_Programs.C) ? adrDetected : adrGuessed;
        if (ret != adrDetected) {
           m_MasterPath = _T("C:\\Program Files\\Catalina");
        }
    else
        m_MasterPath = _T("/usr/local/lib/catalina");
    }
    else {
        m_MasterPath = pathValues;
    }
    wxString BinPath = m_MasterPath + sep + _T("bin");
    ret = wxFileExists(BinPath + sep + m_Programs.C) ? adrDetected : adrGuessed;
    if (ret == adrDetected)
    {
       m_ExtraPaths.Add(BinPath);
       wxString libPathValues;
       wxGetEnv(_T("CATALINA_LIBRARY"), &libPathValues);
       if (!libPathValues.IsEmpty())
       {
          AddLibDir(libPathValues);
       }
       wxString incPathValues;
       wxGetEnv(_T("CATALINA_INCLUDE"), &incPathValues);
       if (!incPathValues.IsEmpty())
       {
          AddIncludeDir(incPathValues);
       }
    }
    return ret;
} // end of AutoDetectInstallationDir
