/*
 * This file is part of the Code::Blocks IDE and licensed under the GNU General Public License, version 3
 * http://www.gnu.org/licenses/gpl-3.0.html
 */

#ifndef COMPILER_CATALINA_H
#define COMPILER_CATALINA_H

#include <compiler.h>

class CompilerCatalina : public Compiler
{
    public:
        CompilerCatalina();
        virtual ~CompilerCatalina();
        virtual void Reset();
        virtual AutoDetectResult AutoDetectInstallationDir();
    protected:
        virtual Compiler* CreateCopy();
};

#endif // COMPILER_CATALINA_H
